﻿CoreChain Decentralized Block Launcher
======================================
1. แตกไฟล์ ZIP นี้ไปยังโฟลเดอร์ที่ต้องการ (เช่น C:\CoreChain)
2. ดับเบิลคลิกที่ CoreChain.exe เพื่อเริ่มทำงาน (ไม่มีจอดำ ทำงานใน System Tray)
3. เปิดเบราว์เซอร์ไปที่ http://localhost (หรือ http://localhost:8080)
4. บัญชี Admin เริ่มต้น: admin / admin1234
